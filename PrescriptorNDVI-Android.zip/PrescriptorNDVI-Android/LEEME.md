# Prescriptor NDVI · app Android

Proyecto Android que empaqueta la app web **Prescriptor NDVI** (el mismo archivo HTML) dentro de una app nativa.
Funciona igual que en el computador: abre el NDVI, RGB y shapefiles desde el teléfono, guarda proyectos y
descarga los .tif + .tfw, shapefiles, .presc e informes en **Descargas/Prescriptor**.

Hay dos formas de obtener el archivo **.apk**:

## Opción A · GitHub (sin instalar nada)

1. Crea una cuenta en github.com (gratis) y un repositorio nuevo, por ejemplo `prescriptor-ndvi`.
2. En el repositorio, pulsa **Add file → Upload files** y arrastra **todo el contenido** de esta carpeta
   (incluida la carpeta oculta `.github`; si tu explorador no la muestra, sube el .zip descomprimido desde la web
   usando "choose your files" y selecciona todas las carpetas).
3. Pulsa **Commit changes**. GitHub empieza a compilar solo (pestaña **Actions → Compilar APK**, demora unos 5 minutos).
4. Cuando aparezca el ✔ verde, entra a la ejecución y descarga **PrescriptorNDVI-apk** (abajo, en *Artifacts*).
   Dentro viene `app-release.apk`.

## Opción B · Android Studio

1. Instala Android Studio (developer.android.com/studio).
2. **File → Open** y elige esta carpeta. Espera a que termine la sincronización de Gradle.
3. **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
4. El archivo queda en `app/build/outputs/apk/debug/app-debug.apk` (o `release/` si usas *Build Variant: release*).

## Instalar en el teléfono

1. Copia el .apk al teléfono (cable, Drive o WhatsApp a ti mismo) y ábrelo.
2. Android pedirá permitir **instalar apps de origen desconocido** para esa app (Archivos, Drive, Chrome…): acepta.
3. Abre **Prescriptor NDVI**.

Requisitos: Android 7.0 o superior. El mapa satelital y las tipografías necesitan internet; el resto funciona sin conexión.

## Notas

- El APK queda firmado con la clave de depuración, suficiente para instalarlo directamente. Para publicarlo en
  Google Play hay que firmarlo con una clave propia.
- Para actualizar la app con una versión nueva del HTML, reemplaza `app/src/main/assets/index.html` y vuelve a compilar.
  Sube `versionCode` en `app/build.gradle` para que el teléfono la acepte como actualización.
- Los proyectos guardados quedan dentro de la app; usa «Exportar archivo (.presc)» para respaldarlos.
- En el teléfono, «Ver informe» guarda el informe en Descargas/Prescriptor y lo abre en el navegador, donde se puede
  imprimir o guardar como PDF.
